  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
<br>
<?php include 'headimage.php';?>
<style> 
#panel, #flip { padding: 5px; text-align: center; background-color: #e5eecc; border: solid 1px #c3c3c3;}
#panel { padding: 50px; display: none;}
div.w3-content { margin-left:  }
</style>
<div class="w3-container">
  <br>
 <script>
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").toggle();
    });
});
</script>
<div id="flip" class="w3-black w3-btn-block">Description</div>
<div id="panel"><p>In this example, the sidenav is hidden (style="display:none") and is only shown when you click on the menu icon in the top left corner. When it is opened, it shifts the page content to the right (we use JavaScript to add a 25% left margin to the div element with id="main" when this happens. The value "25%" matches the value used to set the width of the sidenav. Tip: If you change the left margin to 40%, you should change the width of the sidenav to 40% as well.</p></div>
</div>

<?php
include_once 'function/listimage.php';
?>

<?php echo grupimage(); ?>