<?php include_once 'function/listcontact.php';?>
  <nav class="w3-sidenav w3-collapse w3-white w3-card-4 w3-animate-left w3-quarter" style="display:none" id="mySidenav">
  <a href="javascript:void(0)" 
  onclick="w3_close()"
  class="w3-closenav w3-large w3-hide-large">Close &times;</a>
  <a class="active" id="home" href="home.php" target="target_Iframe" class="w3-btn-block">Home</a>
  <a class="" id="image"  href="image.php" target="target_Iframe" class="w3-btn-block">Image</a>
  <a class="" id="artikel"  href="artikel.php" target="target_Iframe" class="w3-btn-block">Artikel</a>
  <a class="" id="profil"  href="profil.php" target="target_Iframe" class="w3-btn-block">Profil</a>
  <a class="" id="contact"  href="contact.php" target="target_Iframe" class="w3-btn-block">Contact Us</a>
  <a id="logout"  href="logout.php" class="w3-btn-block">Logout</a>
</nav>
<script>
$(document).ready(function(){
    $("#home").click(function(){
        $("#home").addClass("active");
        $("#image,#artikel,#profil,#contact").removeClass("active");
    });
});
$(document).ready(function(){
    $("#image").click(function(){
        $("#image").addClass("active");
        $("#contact,#artikel,#profil,#home").removeClass("active");
    });
});
$(document).ready(function(){
    $("#artikel").click(function(){
        $("#artikel").addClass("active");
        $("#image,#contact,#profil,#home").removeClass("active");
    });
});
$(document).ready(function(){
    $("#profil").click(function(){
        $("#profil").addClass("active");
        $("#image,#artikel,#contact,#home").removeClass("active");
    });
});
$(document).ready(function(){
    $("#contact").click(function(){
        $("#contact").addClass("active");
        $("#image,#artikel,#profil,#home").removeClass("active");
    });
});
$(document).ready(function(){
    $("#logout").click(function(){
        $("#logout").addClass("active");
    });
});
</script>
<style>
  nav {
    margin-top: 5px;
  }
  #logout {
    color: #333333;
    background-color: #ffffff;
    text-align: left;
  }
  .active {
    background-color: #555555;
    color: #eeeeee;
    font-style: italic;
    font-weight: bold; 
  }
 a#home:hover,#image:hover,#artikel:hover,#profil:hover,#contact:hover,#logout:hover {
  background-color: #999999;
  color: #111111;
  font-weight: bold;
 }
  iframe {
    border: none;
  }
  /* col-sm-10 */
  @media(min-width:1030px ){
    div#main {
      margin-left: 25%;
      width: 75%;
      float: right; 
    }
    nav a.w3-closenav{
      display: none;
    }
    iframe{
      background-color: white;
      overflow: hidden;
      height: 100%;
      width: 100%;
    }
    header span.w3-opennav {
      display: none;
    }
  }
</style>
<div id="main" class="w3-camo-black" >

<header style="" class="w3-container col-9 w3-camo-black">
  <span class="w3-opennav w3-xlarge w3-left w3-hover-text-grey" onclick="w3_open()" style="padding-top: 10px;" id="openNav">&#9776;</span>
  <h1 class="w3-center" style="padding-left: 25%">Welcome to B4</h1>
</header>
<script type="text/javascript" src="assets/js/jquery.iframe-auto-height.plugin.js"></script>
<script type="text/javascript" src="assets/js/jquery.browser.js"></script>

<script type="text/javascript">
      jQuery(function() {
        jQuery('iframe').iframeAutoHeight({debug: false, diagnostics: false, timeInterval:400, minHeight: 320, defaultHeight: 400});
        // jQuery('#test-iframe').iframeAutoHeight({debug: false, diagnostics: false, timeInterval:500, minHeight: 320, defaultHeight: 400});
      });
</script>
<?php
  echo viewdetpro();
?>
<?php include 'footer.php';?>
</div>


<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidenav").style.width = "25%";
  document.getElementById("mySidenav").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidenav").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>
