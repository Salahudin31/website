  <?php include_once 'function/listcontact.php';?>
  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
<style type="text/css">
  a {
    color: #696969;
  }
  a:hover, li:hover {
    text-decoration: none;
    color: #111111;
    background-color: #dcdcdc;
  }
</style>
<div class="w3-container">
  <h4>List nama kelas</h4>
  <?php echo viewcontact(); ?>
</div>
<style>
  ul li {
    list-style: none;
  }
</style>
<br>