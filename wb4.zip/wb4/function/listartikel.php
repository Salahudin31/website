<?php
function grupartikel(){
	$listartikel = 'daftarartikel.php';
	echo "	<section>
		<h4>Pemrograman WEB </h4>
		<hr size='1' width='30%'><br>
			<a href='././$listartikel'><div class='card-4 w3-half'>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
			</div></a>
		<h4>Pemrograman WEB </h4>
		<hr size='1' width='30%'><br>
			<a href='././$listartikel'><div class='card-4 w3-half'>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
			</div></a>
	</section>		
	<section>
		<h4>Pemrograman WEB </h4>
		<hr size='1' width='30%'><br>
			<a href='././$listartikel'><div class='card-4 w3-half'>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
			</div></a>
			<h4>Pemrograman WEB </h4>
			<hr size='1' width='30%'><br>
			<a href='././$listartikel'><div class='card-4 w3-half'>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/save_the_earth-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
				<div class='w3-third img'><img src='assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg' width='95%' class='w3-opacity-min'></div>
			
				<div class='w3-third img'><img src='assets/image/lighthouse_ship-wallpaper-1366x768.jpg' width='95%' class='w3-opacity-min'></div>
			</div></a>
		</section>";
}
function viewartikel(){
	if(isset($_GET['listartikel'])){
    $listartikel = $_GET['listartikel'];

    echo "<iframe src='listartikel.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
function viewdetartikel(){
	if(isset($_GET['listartikel'])){
    $listartikel = $_GET['listartikel'];

    echo "<iframe src='listdetailartikel.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
?>