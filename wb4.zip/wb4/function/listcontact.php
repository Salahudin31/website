<?php

function viewcontact(){
  $detpro = 'detailcontact.php';
  echo "<ul class='w3-ul w3-card-4'>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/pp.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Gilang</span><br>
      <span>Web Designer</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/images.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Dovi</span><br>
      <span>Support</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
     <img src='assets/image/ps.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Damar</span><br>
      <span>Accountant</span>
    </li> </a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/pp.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Gilang</span><br>
      <span>Web Designer</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/images.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Dovi</span><br>
      <span>Support</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
     <img src='assets/image/ps.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Damar</span><br>
      <span>Accountant</span>
    </li> </a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/pp.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Gilang</span><br>
      <span>Web Designer</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/images.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Dovi</span><br>
      <span>Support</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
     <img src='assets/image/ps.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Damar</span><br>
      <span>Accountant</span>
    </li> </a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/pp.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Gilang</span><br>
      <span>Web Designer</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/images.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Dovi</span><br>
      <span>Support</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
     <img src='assets/image/ps.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Damar</span><br>
      <span>Accountant</span>
    </li> </a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/pp.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Gilang</span><br>
      <span>Web Designer</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
      <img src='assets/image/images.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Dovi</span><br>
      <span>Support</span>
    </li></a>
    <a href='././$detpro'  target='target_Iframe'><li class='w3-padding-16'>
     <img src='assets/image/ps.jpg' class='w3-left w3-circle w3-margin-right' style='width:60px'>
      <span class='w3-xlarge'>Damar</span><br>
      <span>Accountant</span>
    </li> </a>
  </ul>";
}

function viewdetpro(){
  if(isset($_GET['detpro'])){
    $detpro = $_GET['detpro'];

    echo "<iframe id='if' src='profil.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
  echo "<iframe id='if' src='home.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
}
?>