<?php
function grupimage(){
	$listimage = 'daftarimage.php';
	echo "<div class='w3-container'>
  <div class='w3-row-padding w3-margin-top'>
  <div class='w3-third'>
    <div class='w3-card-4'>
  <a href='././$listimage' ><img src='assets/image/cube_fire_dark_light_alloy_36536_1366x768.jpg' class='w3-hover-grayscale' style='width:100%'></a>
      <div class='w3-container'>
        <h5>5 Terre</h5>
      </div>
    </div>
  </div>

  <div class='w3-third'>
    <div class='w3-card-4'>
  <a href='././$listimage' ><img src='assets/image/cube_fire_dark_light_alloy_36536_1366x768.jpg' class='w3-hover-grayscale' style='width:100%'></a>
      <div class='w3-container'>
        <h5>Monterosso</h5>
      </div>
    </div>
  </div>

  <div class='w3-third'>
    <div class='w3-card-4'>
  <a href='././$listimage' ><img src='assets/image/cube_fire_dark_light_alloy_36536_1366x768.jpg' class='w3-hover-grayscale' style='width:100%'></a>
      <div class='w3-container'>
        <h5>Vernazza</h5>
      </div>
    </div>
  </div>
</div>

<div class='w3-row-padding w3-margin-top'>
  <div class='w3-third'>
    <div class='w3-card-4'>
  <a href='././$listimage' ><img src='assets/image/cube_fire_dark_light_alloy_36536_1366x768.jpg' class='w3-hover-grayscale' style='width:100%'></a>
      <div class='w3-container'>
        <h5>Manarola</h5>
      </div>
    </div>
  </div>

  <div class='w3-third'>
    <div class='w3-card-4'>
  <a href='././$listimage' ><img src='assets/image/cube_fire_dark_light_alloy_36536_1366x768.jpg' class='w3-hover-grayscale' style='width:100%'></a>
      <div class='w3-container'>
        <h5>Corniglia</h5>
      </div>
    </div>
  </div>

  <div class='w3-third'>
    <div class='w3-card-4'>
  <a href='././$listimage' ><img src='assets/image/cube_fire_dark_light_alloy_36536_1366x768.jpg' class='w3-hover-grayscale' style='width:100%'></a>
      <div class='w3-container'>
        <h5>Riomaggiore</h5>
      </div>
    </div>
  </div>
</div>
<br>
";
}
function viewimage(){
	if(isset($_GET['listimage'])){
    $listimage = $_GET['listimage'];

    echo "<iframe src='listimage.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
function viewdetimage(){
	if(isset($_GET['listimage'])){
    $listimage = $_GET['listimage'];

    echo "<iframe src='listdetailimage.php' name='target_Iframe' frameborder='0' width='100%'  scrolling='NO'></iframe>";
  }
}
?>