<?php 
require 'core/import.php';
$general->logged_out_protect();
session_start();
session_destroy();
header('Location:index.php');
?>