<footer class="w3-container">
  <h5>Footer</h5>
  <p>Footer information goes here</p>
</footer>
<style type="text/css">
	footer {
		text-align: center;
		background-color: #777777;
	}
	h5 {
		margin: 0px 0px -2px 0px;
		padding: 15px 0px 0px 0px;
	}
	p {
		padding: 0px 0px 10px 0px;
	}
</style>