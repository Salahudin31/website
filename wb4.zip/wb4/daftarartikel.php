 <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>

<div class="w3-container">
	<div class="w3-third" style="width: 100%">
  <a href="detailartikel.php"><div class="w3-card-4" style="margin: 2%;">
    <img src="assets/image/lighthouse_ship-wallpaper-1366x768.jpg" style="width:100%; height: 200px">
    <div class="w3-container">
      <h4>Monterosso [...]</h4>
    </div>
  </div></a>
</div>
<div class="w3-third" style="width: 100%">
  <div class="w3-card-4" style="margin: 2%;">
    <img src="assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg" style="width:100%; height: 200px">
    <div class="w3-container">
      <h4>Monterosso <a href="">[...]</a></h4>
    </div>
  </div>
</div>
<div class="w3-third" style="width: 100%">
  <div class="w3-card-4" style="margin: 2%;">
    <img src="assets/image/save_the_earth-wallpaper-1366x768.jpg" style="width:100%; height: 200px">
    <div class="w3-container">
      <h4>Monterosso <a href="">[...]</a></h4>
    </div>
  </div>
</div>
<div class="w3-third" style="width: 100%">
  <div class="w3-card-4" style="margin: 2%;">
    <img src="assets/image/save_the_earth-wallpaper-1366x768.jpg" style="width:100%; height: 200px">
    <div class="w3-container">
      <h4>Monterosso <a href="">[...]</a></h4>
    </div>
  </div>
</div>
<div class="w3-third" style="width: 100%">
  <div class="w3-card-4" style="margin: 2%;">
    <img src="assets/image/lighthouse_ship-wallpaper-1366x768.jpg" style="width:100%; height: 200px">
    <div class="w3-container">
      <h4>Monterosso <a href="">[...]</a></h4>
    </div>
  </div>
</div>
<div class="w3-third" style="width: 100%">
  <div class="w3-card-4" style="margin: 2%;">
    <img src="assets/image/nature_hd_beach_apocalypse_alteration_water_rocks_sky_19527_1366x768.jpg" style="width:100%; height: 200px">
    <div class="w3-container">
      <h4>Monterosso <a href="">[...]</a></h4>
    </div>
  </div>
</div>
</div>