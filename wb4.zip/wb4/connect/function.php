<? php 

function authenticate($con,$login_user,$login_pass){
        $ip_addr = $_SERVER['REMOTE_ADDR'];
        $sql = "SELECT * FROM user WHERE username='$login_user' AND password='$login_pass' AND status='0'";
       // echo $sql;exit;
	$res = $con->query($sql) or die(mysqli_error());
		$row = $res->fetch_array();
        //	echo json_encode($row);exit;
	if($row) {
                $sql_update = "UPDATE user SET lcount = lcount + 1, last_login_ip = '$ip_addr',modified=now() WHERE loginid='$login_user' AND password='$login_pass'";
                $con->query($sql_update);
				$sqllogin = "INSERT INTO log_activity (log_userid,log_ip,log_remark) VALUES ('$login_user','$ip_addr','LOGIN')";
				$con->query($sqllogin);
                return $row;
        } else return 1;
}

?>