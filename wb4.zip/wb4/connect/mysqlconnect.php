<?php
	$con = @new mysqli(HOST,USER,PASS,DBNAME) or die("GAGAL TERKONEKSI");
	if ($con->connect_errno) {
 		 printf("Connect failed: %s\n", $con->connect_error);
   		exit; 
}

?>