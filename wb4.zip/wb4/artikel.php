<?php
	include_once 'function/listartikel.php';
?>
  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>

<div class="w3-container ">
<?php echo grupartikel(); ?>
	</div>

	<br>
	<br>
	<br>
<style>
	div.w3-container {
		margin: auto;
		display: flex;
	}
	hr {
		margin: 15px 0px -25px 0px;
	}
	div.card-4 {
		width: 95%;
		margin: 10px;
		padding: 10px;
    box-shadow: 0px 1px 1px 1px #222222;
	}
	div.img {
		padding-left: 7px;
		margin: 3px 0px 7px 0px;

	}
	img:hover {
		opacity: 1;
		box-shadow: 4px 4px 4px 4px #333333;
	}
</style>