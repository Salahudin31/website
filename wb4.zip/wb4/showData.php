<?php 
include "db.php";
	
$dbKoneksi=new db('mahasiswa');
//dbkoneksi -> server='192.168.100.2';
$koneksi=$dbKoneksi->open();
$sql="select * from mahasiswa";

$datasiswa=$dbKoneksi->recordset($sql,$koneksi);
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Data Mahasiswa</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css" >
  </head>
  <body>
  <div class="container">
        <h1>Data Mahasiswa</h1>

        <a href="add.php" class="btn btn-success btn-sm">Tambah Data</a>
        <table class="table table-striped table-bordered table-dark text-center">
		  <thead>
		    <tr>
		      <th>NIM</th>
		      <th>Nama Mahasiswa</th>
		      <th>Email</th>
		      <th>Telp</th>
		      <th>Alamat</th>
		      <th>Aksi</th>
		    </tr>
		  </thead>
		  <tbody>
		    <?php foreach($datasiswa as $rec):?>
		    <tr>
		      <td><?php echo $rec['nim'];?></td>
		      <td><?php echo $rec['nama'];?></td>
		      <td><?php echo $rec['email'];?></td>
		      <td><?php echo $rec['telp'];?></td>
		      <td><?php echo $rec['alamat'];?></td>
		      <td><a href="edit.php?nim=<?php echo $rec['nim'];?>" class="btn btn-primary btn-sm">edit</a>&emsp;<a href="delete.php?nim=<?php echo $rec['nim'];?>" class="btn btn-danger btn-sm">delete</a></td>
		    </tr>
		   <?php endforeach;?> 
		  </tbody>
		</table>
  </div>      
  </body>
</html>