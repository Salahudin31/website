  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>
<?php include_once 'function/newshome.php'; ?>
<iframe src="contact.php" width="100%" height="200" ></iframe>
<style>
  h4.title { padding-left: 5%; color: #222222;  }
	iframe {
		border: none;
		margin-bottom: 20px;
	}
	img {
		padding-left: 4%;
	}
  h3,h5 {
    margin-left: 1%;
  }
  p {
    margin-left: 3%;
  }
	a{
		float: right;
		padding-right: 10%;
	}
</style>
<?php echo listnew(); ?>