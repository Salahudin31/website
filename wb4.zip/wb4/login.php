<?php 
require 'core/import.php';
$general->logged_in_protect();
if (empty($_POST) === false)
{	$username = strip_tags(addslashes(trim($_POST['userid']))); 
	$password = strip_tags(addslashes(trim($_POST['password']))); 
	if (empty($username) === true || empty($password) === true) {
		$errors[] = 'Sorry, but we need your username and password.';
	} else if ($user->user_exists($username) === false) {
		$errors[] = 'Sorry, that username doesn\'t exists. Please try again.';
	} 
	else
	{	$login = $user->login($username, $password);
		if ($login === false) {
			$errors[] = 'Sorry, that username/password is invalid. Please try again.';
		}else {
			$_SESSION['loginid'] =  $login;
			echo $login;
			header('location: index1.php');
			exit();
		}
	}
} 
?>
<!DOCTYPE html>
<html>
<head>
<title>Login Helpdesk System</title>
</head>
<body onload="document.login.username.focus();" style="background-color: #999999">
<br/><br/>
<h1 class="loginform" style="text-align: center;">Login Webb4</h1>
<div class="loginform" align="center" style="box-shadow: 1px 1px 2px 6px #333333; background-color: #ffffff; width: 700px; position: relative; left: 26%;">
	<table class="loginform">
	<tr><td>
		<img src="assets/image/b4-recipe.png" alt="Company-Logo" align="middle">
	</td>
	<td>
		<form name="login" method="post" style="position: relative; right: 15%;">
		<fieldset><legend>&nbsp;Please Log in&nbsp;</legend>
		<label>User Name : </label>
		<input type="text" name="userid" autocomplete="off" size="20"><br />
		<label>Password : </label>
		<input type="password" name="password" autocomplete="off" size="20"><br /><br />
		<center><input type="submit" name="login" value="Login" ></center>
		</fieldset>
		</form>
	</td>
	</tr>
	</table>
</div>
<?php 
	if(empty($errors) === false){
		echo '<p class="errormsg">' . implode('</p><p class="errormsg">', $errors) . '</p>';	
	}
?>
<div class="footer">
</div>
</body>
</html>