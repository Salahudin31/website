<?php
class News
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function add_news($new_id,$nama_new,$kategori_id,$id_table,$desc_new,$tgl_buat){
		$query = $this->db->prepare("INSERT INTO `news` (`new_id`,`nama_new`,`kategori_id`,`id_table`,`desc_new`,`tgl_buat`) VALUES (?,?,?,?,?,?)");
		$query->bindValue(1,$new_id);
		$query->bindValue(2,$nama_new);
		$query->bindValue(3,$kategori_id);
		$query->bindValue(4,$id_table);
		$query->bindValue(5,$desc_new);
		$query->bindValue(6,$tgl_buat);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_news($new_id,$nama_new,$kategori_id,$id_table,$desc_new,$tgl_buat){
		$query = $this->db->prepare("UPDATE `news` SET `nama_new` = ? ,`kategori_id` = ? , `id_table` = ?, `desc_new` = ? , `tgl_buat` = ? WHERE `new_id` = ?");
		$query->bindValue(1,$nama_new);
		$query->bindValue(2,$kategori_id);
		$query->bindValue(3,$id_table);
		$query->bindValue(4,$desc_new);
		$query->bindValue(5,$tgl_buat);
		$query->bindValue(6,$new_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($new_id){
		$sql="DELETE FROM `news` WHERE `new_id` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $new_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function news_data($new_id){
		$query = $this->db->prepare("SELECT * FROM `news` WHERE `new_id`= ?");
		$query->bindValue(1, $new_id);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_news_kategori(){
		$query = $this->db->prepare("SELECT * FROM `news` WHERE `kategori_id`= ?");
		$query->bindValue(1, $kategori_id);
		try{
			$query->execute();
			$rows = $query->fetchColumn();
			if($rows != 0){
				
				return $rows;
			}else{
				
			}
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_news_table(){
		$query = $this->db->prepare("SELECT * FROM `news` WHERE `id_table`= ?");
		$query->bindValue(1, $id_table);
		try{
			$query->execute();
			$rows = $query->fetchColumn();
			if($rows != 0){
				
				return $rows;
			}else{
				
			}
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_news(){
		$query = $this->db->prepare("SELECT * FROM `news` ORDER BY `tgl_buat` ASC");
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>