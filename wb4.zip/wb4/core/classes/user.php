<?php
class User
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	public function user_exists($userid) 
	{	$query = $this->db->prepare("SELECT COUNT(`id`) FROM `user` WHERE `userid`= ?");
		$query->bindValue(1, $userid);
		try
		{	$query->execute();
			$rows = $query->fetchColumn();
			if($rows == 1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage());
		}
	}
	public function register($userid,$password,$nama,$alamat,$tgl_lahir,$hobi,$fotoprofil,$email,$website,$confirm)
	{	
		$userid = sha1($userid + microtime());
		$password   = sha1($password);
	 	$query 	= $this->db->prepare("INSERT INTO `user` (`userid`, 
	 		`password`, `nama`, `alamat`, `tgl_lahir`,`hobi`, `fotoprofil`, `email`, `website`, `confirm`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	 	$query->bindValue(1, $userid);
		$query->bindValue(2, $password);
		$query->bindValue(3, $nama);
		$query->bindValue(4, $alamat);
		$query->bindValue(5, $tgl_lahir);
		$query->bindValue(6, $hobi);
		$query->bindValue(7, $fotoprofil);
		$query->bindValue(8, $email);
		$query->bindValue(9, $website);
		$query->bindValue(10, 1);
	 	try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	public function update($id,$userid,$password,$nama,$alamat,$tgl_lahir,$hobi,$fotoprofil,$email,$website,$confirm)
	{	
		$userid = sha1($userid + microtime());
		$password   = sha1($password);
	 	$query 	= $this->db->prepare("UPDATE `user` SET `userid` = ? , `nama` = ? , `alamat` = ? , `tgl_lahir` = ? , `hobi` = ? , `fotoprofil` = ? ,`email` = ? , `website` = ? , `confirm` = ? WHERE `id` = ? ");

		$query->bindValue(1, $userid);
		$query->bindValue(2, $nama);
		$query->bindValue(3, $alamat);
		$query->bindValue(4, $tgl_lahir);
		$query->bindValue(5, $hobi);
		$query->bindValue(6, $fotoprofil);
		$query->bindValue(7, $email);
		$query->bindValue(8, $website);
		$query->bindValue(9, $confirm);
		$query->bindValue(10, $id);

	 	try{
			$query->execute();
		}
		catch(PDOException $e){
			die($e->getMessage());
		}
	}
	public function changepwd($id,$password)
	{	$password   = sha1($password);
	 	$query 	= $this->db->prepare("UPDATE `user` SET `password` = ? WHERE `id` = ?");
		$query->bindValue(1, $password);
		$query->bindValue(2, $id);
	 	try{
			$query->execute();
		}
		catch(PDOException $e){
			die($e->getMessage());
		}
	}
	public function delete($id){
		$sql="DELETE FROM `users` WHERE `id` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $id);
		try{
			$query->execute();
		}
		catch(PDOException $e){
			die($e->getMessage());
		}
	}
	
	
	public function login($userid, $password)
	{	$query = $this->db->prepare("SELECT `password`, `id` FROM `user` WHERE `userid` = ?");
		$query->bindValue(1, $userid);
		try{
			$query->execute();
			$data 				= $query->fetch();
			$stored_password 	= $data['password'];
			$id   				= $data['id'];
			if($stored_password === sha1($password)){
				return $id;	
			}else{
				return false;	
			}
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	public function userdata($id)
	{	$query = $this->db->prepare("SELECT * FROM `user` WHERE `id`= ?");
		$query->bindValue(1, $id);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	public function get_user_by_id($id)
	{	$query = $this->db->prepare("SELECT * FROM `user` WHERE `id`= ?");
		$query->bindValue(1, $id);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	} 
}
?>