<?php
class Tbl_Image
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function add_tbl_image($id_table,$nama_table,$date_table){
		$query = $this->db->prepare("INSERT INTO `tbl_image` (`id_table`,`nama_table`,`date_table`) VALUES (?,?,?)");
		$query->bindValue(1,$id_table);
		$query->bindValue(2,$nama_table);
		$query->bindValue(3,$date_table);
		try{
			$query->execute();			
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_tbl_image($id_table,$nama_table){
		$query = $this->db->prepare("UPDATE `tbl_image` SET `nama_table` = ? , `date_table` = ? WHERE `id_table` = ?");
		$query->bindValue(1,$nama_table);
		$query->bindValue(2,$date_table);
		$query->bindValue(3,$id_table);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($id_table){
		$sql="DELETE FROM `tbl_image` WHERE `id_table` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $id_table);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function tbl_image_data($id_table){
		$query = $this->db->prepare("SELECT * FROM `tbl_image` WHERE `id_table`= ?");
		$query->bindValue(1, $id_table);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_tbl_image(){
		$query = $this->db->prepare("SELECT * FROM `tbl_image` ORDER BY `date_table` ASC");
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>