<?php
class Artikel
{
	private $db;
	function __construct($database)
	{
		$this->db=$database;
	}
	function daftar_artikel($nama_artikel){
		$query = $this->db->prepare("SELECT COUNT(`artikel_id`) FROM `artikel`= ?");
		$query->bindValue(1,$nama_artikel);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage()); 
		}
	}
	function daftar_artikelSemester($semester_id){
		$query = $this->db->prepare("SELECT COUNT(`artikel_id`) FROM `semester_id`= ?");
		$query->bindValue(2,$semester_id);
		try {
			$query->execute();
			$row=$query->fecthColumn();
			if($row==1){
				return true;
			}else{
				return false;
			}
		} catch (PDOException $e){
			die($e->getMessage());
		}
	}
	function add_artikel($artikel_id,$nama_artikel,$kategori_matkul_kd_id,$file_artikel,$semester_id,$key_search){
		$query = $this->db->prepare("INSERT INTO `artikel` (`artikel_id`,`nama_artikel`,`kategori_matkul_kd_id`,`file_artikel`,`semester_id`,`key_search`) VALUES (?,?,?,?,?,?)");
		$query->bindValue(1,$artikel_id);
		$query->bindValue(2,$nama_artikel);
		$query->bindValue(3,$kategori_matkul_kd_id);
		$query->bindValue(4,$file_artikel);
		$query->bindValue(5,$semester_id);
		$query->bindValue(6,$key_search);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function update_artikel($artikel_id,$nama_artikel,$kategori_matkul_kd_id,$file_artikel,$semester_id,$key_search){
		$query = $this->db->prepare("UPDATE `artikel` SET `nama_artikel` = ? ,`kategori_matkul_kd_id` = ? , `file_artikel` = ? , `semester_id` = ? , `key_search` = ? WHERE `artikel_id` = ?");
		$query->bindValue(1,$nama_artikel);
		$query->bindValue(2,$kategori_matkul_kd_id);
		$query->bindValue(3,$file_artikel);
		$query->bindValue(4,$semester_id);
		$query->bindValue(5,$key_search);
		$query->bindValue(6,$artikel_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function delete($artikel_id){
		$sql="DELETE FROM `artikel` WHERE `artikel_id` = ?";
		$query = $this->db->prepare($sql);
		$query->bindValue(1, $artikel_id);
		try{
			$query->execute();
		}catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function artikel_data($artikel_id){
		$query = $this->db->prepare("SELECT * FROM `artikel` WHERE `artikel_id`= ?");
		$query->bindValue(1, $artikel_id);
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_artikel(){
		$query = $this->db->prepare("SELECT * FROM `artikel` ORDER BY `semester_id` ASC");
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
	function get_kategori_artikel(){
		$query = $this->db->prepare("SELECT * FROM `artikel` ORDER BY `kategori_matkul_kd_id` ASC");
		try{
			$query->execute();
			return $query->fetch();
		} catch(PDOException $e){
			die($e->getMessage());
		}
	}
}
?>