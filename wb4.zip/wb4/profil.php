  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/w3/w3.css" rel="stylesheet">
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery-1.11.3.min.js"></script> 
  <script src="assets/js/jquery.min.js"></script>

<div class="w3-row-padding ">

<div class="w3-twothird">
  <br>
  <img src="assets/image/ps.jpg" class="w3-round" style="width:50%">
  <h2>Food</h2>
  <table class="w3-table w3-striped w3-bordered w3-border">
  <thead class="w3-teal"><th style="width:30%">Food</th><th>Type</th></thead>
  <tr><td style="width:30%">Seafood</td><td>Shrimps, Crab, Lobster</td></tr>
  <tr><td>Meat</td><td>Chicken, Pork</td></tr>
  <tr><td>Cheese</td><td>Brie, Gruyere</td></tr>
  <tr><td>Other</td><td>Cream sauces</td></tr>
  </table>
  <h2>Flavours</h2>
  <table class="w3-table w3-striped w3-bordered w3-border">
  <thead class="w3-teal"><th style="width:30%">Age</th><th>Flavor</th></thead>
  <tr><td>Less Ripe</td><td>Green Plum, Green Apple, Pear </td></tr>
  <tr><td>Medium</td><td>Lemon, Peach, Melon</td></tr>
  <tr><td>More Ripe</td><td>Pineapple, Fig, Banana, Mango</td></tr>
  <tr><td>Oaked</td><td>added Cream or Butter</td></tr>
  </table>
  <h2>Neighbours</h2>
  <table class="w3-table w3-striped w3-bordered w3-border">
  <thead class="w3-teal"><th style="width:30%">Neighbour</th><th>Flavour</th></thead>
  <tr><td>Pinot Gris</td><td>Like under-riped Chardonnay </td></tr>
  <tr><td>Semillion</td><td>Lighter with more lemon</td></tr>
  <tr><td>Viognier</td><td>More Vanilla, Flowers or Perfume</td></tr>
  </table> 
</div>

<div class="w3-third">
  <h1>Chardonnay</h1>
  <p>Chardonnay is the world's most popular wine grape.</p>
  <p>The taste of the Chardonnay grape is very neutral and easy to like.</p>
  <p>Many of the Chardonnay flavors are derived from terroir and oak-aging.</p>
  <p>The flavors varies from noticeable acidity (Cold Climates), to crisply and mineral (Chablis, France) 
  with flavors of green plum, apple and pear, to heavy oak and tropical fruit flavors (the New World). </p>
  <p>In cooler climates Chardonnay tends to be under-riped. </p>
  <p>In warmer climates the flavors tend to vary from lemon to peach and melon.</p>
  <p>In very warm climates Chardonnay tends to be over-riped.</p>
  <p>Oaked Chardonnay tends to have softer acidity and more fruit flavors with 
  added butter, cream and hazelnut notes.</p>
 </div>

</div><br>