<html>
    <head>
        <title>Variabel dan operator</title>
    </head>
    <body>
        <h1>IF THEN ELSE</h1>
        <?php 
            $_5hariKerja=0;
            $JumlahKerja=$_5hariKerja ?20:25; // apakah jumlah kerja sama dengan 5 hari kerja ?
                                              // Jika iya (nilai = 1) = 20 , jika tidak (nilai=0) = 25.  

            $isKontrak=1;
            $transport=$isKontrak ?15000:25000;// apakah transport sama dengan isKontrak ?
                                              // Jika iya (nilai = 1) = 15000 , jika tidak (nilai=0) = 25000
            
            $UTransport=$JumlahKerja*$transport;

        ?>

        <h1>Uang transport Anda <?php echo number_format($UTransport,2,'.',',');?></h1>
    
    </body>
</html>